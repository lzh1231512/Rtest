﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PlaywrightTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Test();
            var targetFolder = Path.Combine(AppContext.BaseDirectory, "Output");
            //var result1 = GetResult(123, targetFolder);
            //var result2 = GetResult(1156, targetFolder);
            //var result3 = GetResult(2345, targetFolder);

            int batchSize = 1000;
            int total = 1000000;
            for (int i = 13; i < total / batchSize; i++)
            {
                var startTime = DateTime.Now;
                var filePath = Path.Combine(targetFolder, $"output_{i}.bin");
                string[] results = new string[batchSize];
                var list = new List<int>();
                using var tool = new PlaywrightTool();
                for (int j = 0; j < batchSize; j++)
                {
                    int number = i * batchSize + j;
                    list.Add(number);
                }
                var encryptedTask = tool.ProcessAsync(list);
                encryptedTask.Wait();
                results = encryptedTask.Result.ToArray();

                using (var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (var bw = new BinaryWriter(fs))
                {
                    for (int j = 0; j < batchSize; j++)
                    {
                        var bytes = System.Text.Encoding.UTF8.GetBytes(results[j]);
                        bw.Write((ushort)bytes.Length); // 2 bytes length prefix
                        bw.Write(bytes);
                    }
                }
                Console.WriteLine($"Written batch {i + 1}/{total / batchSize}; time : ${(DateTime.Now-startTime).TotalSeconds}");
            }
            

        }
        static void Test()
        {
            for (int i = 0; i < 200; i++)
            {
                //生成0-12000之间的随机数
                Random rand = new Random();
                int value = rand.Next(0, 12000);
                var result1 = GetResult(value);
                var tool = new PlaywrightTool();
                var list = new List<int> { value };
                var encryptedTask = tool.ProcessAsync(list);
                encryptedTask.Wait();
                var results = encryptedTask.Result;
                if(result1 != results[0])
                {
                    Console.WriteLine($"Mismatch at index {value}: file result = {result1}, tool result = {results[0]}");
                }
            }
        }
        // index: 1-based
        static string GetResult(int index)
        {
            var targetFolder = Path.Combine(AppContext.BaseDirectory, "Output");
            int batchSize = 1000;
            int zeroBased = index;
            int fileIndex = zeroBased / batchSize;
            int innerIndex = zeroBased % batchSize;
            var filePath = Path.Combine(targetFolder, $"output_{fileIndex}.bin");
            if (!File.Exists(filePath)) return null;
            using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var br = new BinaryReader(fs))
            {
                for (int i = 0; i <= innerIndex; i++)
                {
                    var len = br.ReadUInt16();
                    var bytes = br.ReadBytes(len);
                    if (i == innerIndex)
                        return System.Text.Encoding.UTF8.GetString(bytes);
                }
            }
            return null;
        }
    }
}

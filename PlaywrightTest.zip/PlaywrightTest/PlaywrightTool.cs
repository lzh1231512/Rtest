﻿using Microsoft.Playwright;
using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

public class PlaywrightTool:IDisposable
{
    private readonly string _htmlRoot;
    private IPlaywright _playwright;
    private IBrowser _browser;
    private readonly object _lock = new();
    private bool _initialized = false;
    private IPage _page;
    private List<string> result= new List<string>();

    public PlaywrightTool()
    {
        // 获取程序当前路径下的 html 文件夹
        _htmlRoot = Path.Combine(AppContext.BaseDirectory, "HTML");
    }

    private async Task EnsureInitializedAsync()
    {
        if (_initialized) return;
        lock (_lock)
        {
            if (_initialized) return;
            _initialized = true;
        }
        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions { Headless = true });
    }

    public async Task<List<string>> ProcessAsync(List<int> id)
    {
        try
        {
            var list = id.Select(f => new VideoModel() { VideoId = f });
            var listJson = JsonSerializer.Serialize(list);
            await EnsureInitializedAsync();

            var tcs = new TaskCompletionSource<List<string>>();

            _page = await _browser.NewPageAsync();
            // 拦截所有请求
            await setEvent(listJson, id,tcs);
            var indexPath = Path.Combine(_htmlRoot, "index.html");
            await _page.GotoAsync($"file:///{indexPath.Replace("\\", "/")}");
            var result = await Task.WhenAny(tcs.Task, Task.Delay(5000+ id.Count*1000));
            if (tcs.Task.IsCompleted)
            {
                return tcs.Task.Result;
            }
            else
            {
                return null;
            }
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    private async Task setEvent(string listJson,
        List<int> id,
        TaskCompletionSource<List<string>> tcs)
    {
        await _page.RouteAsync("**/*", async route =>
        {
            var url = route.Request.Url;
            try
            {
                if (url.EndsWith("main.js"))
                {
                    var jsPath = Path.Combine(_htmlRoot, "main.js");
                    var jsContent = await File.ReadAllTextAsync(jsPath);
                    await route.FulfillAsync(new RouteFulfillOptions
                    {
                        Status = 200,
                        ContentType = "application/javascript",
                        Body = jsContent
                    });
                    return;
                }
                if (url.Contains("encrypt"))
                {
                    var jsonPath = Path.Combine(_htmlRoot, "encrypt.json");
                    var jsonContent = await File.ReadAllTextAsync(jsonPath);
                    await route.FulfillAsync(new RouteFulfillOptions
                    {
                        Status = 200,
                        ContentType = "application/json",
                        Body = jsonContent
                    });
                    return;
                }
                if (url.Contains("api/videos/index_byall"))
                {
                    var jsonPath = Path.Combine(_htmlRoot, "main.json");
                    var jsonContent = await File.ReadAllTextAsync(jsonPath);
                    jsonContent = jsonContent.Replace("{id}", listJson);
                    await route.FulfillAsync(new RouteFulfillOptions
                    {
                        Status = 200,
                        ContentType = "application/json",
                        Body = jsonContent
                    });
                    return;
                }
                if (url.Contains("api/videos/img/"))
                {
                    var parts = url.Split(new[] { "/img/" }, StringSplitOptions.None);
                    if (parts.Length > 1)
                    {
                        result.Add(parts[1]);
                        if (result.Count == id.Count)
                        {
                            tcs.TrySetResult(result);
                        }
                    }
                    await route.ContinueAsync();
                    return;
                }

                await route.ContinueAsync();
            }
            catch (Exception ex)
            {
                await route.ContinueAsync();
            }
        });
    }

    public void Dispose()
    {
        _browser?.DisposeAsync().AsTask().Wait();
        _playwright?.Dispose();
    }
}


public class VideoModel
{
    [JsonPropertyName("video_id")]
    public int VideoId { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; } = "1";

    [JsonPropertyName("duration")]
    public int Duration { get; set; } = 5016;

    [JsonPropertyName("video_viewed")]
    public int VideoViewed { get; set; } = 21722;

    [JsonPropertyName("resolution_type")]
    public int ResolutionType { get; set; } = 0;

    [JsonPropertyName("is_private")]
    public int IsPrivate { get; set; } = 0;

    [JsonPropertyName("screen_main")]
    public int ScreenMain { get; set; } = 2;

    [JsonPropertyName("img_opt")]
    public int ImgOpt { get; set; } = 2;

    [JsonPropertyName("is_hd")]
    public int IsHd { get; set; } = 0;
}